<?php
!defined('EMLOG_ROOT') && exit('access deined!');

// 开启插件时执行该函数
function callback_init() {
	// do something
}

// 关闭和删除插件时执行该函数
function callback_rm() {
	// do something
}
